package Model.Dao;

public class UsuarioDAO {
    
    //  Autenticar
    public boolean autenticar(String usuario, String senha){
        
        if(usuario.equals("teste") && senha.equals("1234")){
            return true;}
        else{
                return false;
        }
       
    }
}