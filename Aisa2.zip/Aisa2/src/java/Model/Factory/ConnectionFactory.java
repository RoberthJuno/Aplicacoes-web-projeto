package Model.Factory;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import java.sql.SQLException;

public class ConnectionFactory{
    
    private String url_conexao = "";
    private String usuario = "root";
    private String senha = "123456";
    private Connection conexao = null;
    
    public Connection getConnection(){
        
        try{

            DriverManager.registerDriver(new org.apache.derby.jdbc.ClientDriver());
            //return DriverManager.getConnection(urlDB, user, password);

            conexao = DriverManager.getConnection(url_conexao, usuario, senha);
            
        }catch(SQLException ex){
            
        }
        return conexao;
    }

}